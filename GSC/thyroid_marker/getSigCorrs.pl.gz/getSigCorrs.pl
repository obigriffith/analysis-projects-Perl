#!/usr/bin/perl -w

use strict;

my $datafile="ATC_all_deconvoluted_data_62markers_23JAN07_prim_foci_corrs_summary.txt";

open (DATA, $datafile) or die "can't open $datafile\n";

my $header = <DATA>;
chomp $header;
my @headers = split("\t",$header);

while (<DATA>){
  chomp;
  my @data = split("\t",$_);
  my $marker1= shift @data;
  my $i=1;
  foreach my $corr (@data){
    my $marker2=$headers[$i];
    if ($corr=~/\*/){
      print "$marker1\t$marker2\t$corr\n";
    }
    $i++;
  }
}

close DATA;

exit;
