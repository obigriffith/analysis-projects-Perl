#!/usr/bin/perl -w

use strict;

my %datahash;

my $firstline=<>;
print "$firstline";

while(<>){
  my $line=$_;
  my @data=split("\t",$line);
  my $description=$data[31];

  if ($description=~/^(\d+)\s\|/){
    my $id = $1;
    #print "$id\n";
    $datahash{$id}=$line;
  }
}

foreach my $id (sort{$a<=>$b} keys %datahash){
print "$datahash{$id}";
}
