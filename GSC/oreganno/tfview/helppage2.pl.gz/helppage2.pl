#!/usr/bin/perl -w

use CGI qw/:standard :html3/;

print header(),start_html('Help Page');


print "<body><p><a href=\"http://www.oreganno.org/oregano/Index.jsp\"><img src=\"http://www.oreganno.org/oregano/htdocs/images/oregano-fulltitle-large.png\" alt=\"ORegAnnoHomePage\" border=\"0\" /></a></p></body>";

print "<p>1. The ORegAnno logo has a link to the ORegAnno homepage</p>";
print "<p>2. Clicking on each transcription factor link gives all the binding sites information for that transcription factor in a table format</p>";
print "<p>3. Clicking on the <img src=\"http://www.splitbrain.org/_static/fileicons/file.png\" border=\"\"/> gives the binding sites information in a tab-delimited format which can be saved in a text format as well</p>";


