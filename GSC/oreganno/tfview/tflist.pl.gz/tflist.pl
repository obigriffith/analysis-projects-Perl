#!/usr/bin/perl
#File: tflist.pl
use DBI;
use CGI qw/:standard :html3/;

my $host = "web02";
my $user_name = "viewer";
my $password = "d0gf00d";
my $db_name = "oregano";
my $socket_line = "";

#Establish a database connection. DBI returns a database handle object, which we store into $dbh.
my $dbh = DBI->connect("DBI:mysql:host=$host;database=$db_name" . $socket_line, $user_name, $password, {PrintError => 0,
RaiseError => 1}) || die("Cannot connect to ORegAnno MySQL database at $host");

$speciesname = param('speciesname');

my $speciesid = "SELECT id FROM species WHERE species_name= \"$speciesname\" ";
my $sth1 = $dbh -> prepare($speciesid) or die "couldn't prepare statement: ". $dbh -> errstr;
$sth1 -> execute() or die "Couldn't execute statement: " . $sth1->errstr;
if ($sth1->rows == 0)
{
    print "No record found\n";
    exit;
}  
my @data1;
my $species_id;
@data1 = $sth1-> fetchrow_array();
$species_id = $data1[0];
$sth1 -> finish;


my $tfname = "SELECT tf_name FROM record WHERE type = \"TRANSCRIPTION FACTOR BINDING SITE\" AND species_id = \"$species_id\" AND deprecated_by_date IS NULL";
my $sth2 = $dbh -> prepare($tfname) or die "couldn't prepare statement: ". $dbh -> errstr;
$sth2 -> execute() or die "Couldn't execute statement: " . $sth2->errstr;
if ($sth2->rows == 0)
{
    #print "No record found\n";
    #exit;
}  

print header(),start_html('Transcription Factor List');

 
my @date2;
my %tfnamenum;

for ($i=0; $i<1; $i++)
{
    print "<body><p><a href=\"http://www.oreganno.org/oregano/Index.jsp\"><img src=\"http://www.oreganno.org/oregano/htdocs/images/oregano-fulltitle-large.png\" alt=\"ORegAnnoHomePage\" border=\"0\" /><hr /></a></p></body>";
    print "<p align=\"top\"><a href=\"./helppage2.pl\">Help</a></p>";
    print"<p><a href=\"http://oreganno.phage.bcgsc.ca/tfview/cgi-bin/specieslist.pl\">Back to the species list</a></p>";      
    print "<style type=\"text/css\" media=\"screen\"><!-- \@import url(../table.css); --></style><p><b>Transcription Factors, Numbers and Details of Binding Sites for \"Rattus norvegicus\"</b></p>";

    while (@data2 = $sth2 -> fetchrow())
    {
	$data2[0] =~ tr/a-z/A-Z/ ;
	if ( $tfnamenum{$data2[0]} == 0 )
	{
	    $tfnamenum{$data2[0]} =1;
	}
	else
	{
	    $tfnamenum {$data2[0]}++;
	}
    }
    $sth2 -> finish;

    @keys = keys %tfnamenum;
    $size = scalar @keys;
    #@numtfs = values %tfnamenum;
    #@numtfs = sort {$b <=> $a} @numtfs;
    @keys = sort @keys;

    print "<table class='data' border=\"\" cellpadding=\"2\">";   
    print "<tr align=\"CENTER\" valign=\"TOP\"><th>Transcription Factor</th><th>Number of Binding Sites</th><th> </th></tr>";
    for ($r=0; $r<$size; $r++)
    {	
	print "<tr align=\"CENTER\" valign=\"TOP\"><td><a href=\"./sitelist.pl?speciesname=$speciesname&tf=$keys[$r]\">$keys[$r]</td><td>$tfnamenum{$keys[$r]}</a></td><td><a href=\"./tabdelimitedlist.pl?speciesname=$speciesname&tf=$keys[$r]\"><img src=\"http://www.splitbrain.org/_static/fileicons/file.png\" border=\"\"/></a></tr>";
		  
    }         
} 

print end_html;

