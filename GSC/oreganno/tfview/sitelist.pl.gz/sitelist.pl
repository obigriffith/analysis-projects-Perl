#!/usr/bin/perl
#File: sitelist.pl
use DBI;
use CGI qw/:standard :html3/;

my $host = "web02";
my $user_name = "viewer";
my $password = "d0gf00d";
my $db_name = "oregano";
my $socket_line = "";


#Establish a database connection. DBI returns a database handle object, which we store into $dbh.
my $dbh = DBI->connect("DBI:mysql:host=$host;database=$db_name" . $socket_line, $user_name, $password, {PrintError => 0,
RaiseError => 1}) || die("Cannot connect to ORegAnno MySQL database at $host");

$speciesname = param('speciesname');
$tfname = param('tf');

my $speciesid = "SELECT id FROM species WHERE species_name= \"$speciesname\" ";
my $sth1 = $dbh -> prepare($speciesid) or die "couldn't prepare statement: ". $dbh -> errstr;
$sth1 -> execute() or die "Couldn't execute statement: " . $sth1->errstr;
if ($sth1->rows == 0)
{
    print "No record found\n";
    exit;
}  
my @data1;
my $species_id;
@data1 = $sth1-> fetchrow_array();
$species_id = $data1[0];
$sth1 -> finish;

print header(), start_html('Site List');

my $recordid= "SELECT id FROM record WHERE tf_name=\"$tfname\" AND species_id=\"$species_id\" AND deprecated_by_date IS NULL AND type=\"TRANSCRIPTION FACTOR BINDING SITE\"";
my $sth10= $dbh->prepare($recordid) or die "Couldn't prepare statement: " . $dbh->errstr;
$sth10->execute() or die "Couldn't execute statement: " . $sth10->errstr;
if ($sth10->rows == 0)
{
    print "No record found\n";
    exit;
}  
my @data10;

for ( $i=0; $i<1; $i++)
{
    print "<body><p><a href=\"http://www.oreganno.org/oregano/Index.jsp\"><img src=\"http://www.oreganno.org/oregano/htdocs/images/oregano-fulltitle-large.png\" alt=\"ORegAnnoHomePage\" border=\"0\" /><hr /></a></p></body>";
    print "<p align=\"top\"><a href=\"./helppage3.pl\">Help</a></p>";
    print "<p><a href=\"http://oreganno.phage.bcgsc.ca/tfview/cgi-bin/specieslist.pl\">Back to the species list</a></p>";
    print "<p><a href=\"http://oreganno.phage.bcgsc.ca/tfview/cgi-bin/tflist.pl?speciesname=$speciesname\">Back to the list of transcription factors for $speciesname</a></p>";    
   
    print "<style type=\"text/css\" media=\"screen\"><!-- \@import url(../table.css); --></style><p><b>Target genes and binding site details for the transcription factor \"$tfname\" in \"$speciesname\"</b></p>";

    print "<table class='data' border=\"\">";   
    print "<tr align=\"CENTER\" valign=\"TOP\"><th>Target Gene</th><th>Sequence</th><th>Start</th><th>End</th><th>Chromosome</th><th>Strand</th><th>Genome Build</th><th>Record's Stable ID</th><th>UCSC Link</th></tr>";
    while (@data10 = $sth10->fetchrow_array())
    {
	my $stableid = "SELECT stable_id FROM record WHERE id=\"$data10[0]\"";
	my $sth11 = $dbh -> prepare($stableid) or die "couldn't prepare statement: ". $dbh -> errstr;
	$sth11 -> execute() or die "Couldn't execute statement: " . $sth211>errstr;
	if ($sth11->rows == 0)
	{
	    print "No record found\n";
	    exit;
	}  
	my @data11;
	@data11= $sth11->fetchrow_array();


	my $genename = "SELECT gene_name,regulatory_sequence FROM record WHERE id=\"$data10[0]\"";
	my $sth2 = $dbh -> prepare($genename) or die "couldn't prepare statement: ". $dbh -> errstr;
	$sth2 -> execute() or die "Couldn't execute statement: " . $sth2->errstr;
	if ($sth2->rows == 0)
	{
	    print "No record found\n";
	    exit;
	}  
	my @data2;


	@data2 = $sth2-> fetchrow_array();
	my $seq = "SELECT sequence FROM sequence WHERE id=\"$data2[1]\"";
	my $sth3 = $dbh -> prepare($seq) or die "Couldn't prepare statemnet: " . $dbh -> errstr;
	$sth3->execute() or die "Couldn't execute statement: " . $sth3->errstr;
	if ($sth3->rows == 0)
	{
	    print "No record found\n";
	    exit;
	}  
	my @data3;
	@data3 = $sth3-> fetchrow_array();


	my $info = "SELECT start,end,sequence_region_name,strand,mapping_genome_id FROM mapping WHERE record_id=\"$data10[0]\" ORDER BY entry_date DESC";
	my $sth4 = $dbh->prepare($info) or die "Couldn't prepare statement: " . $dbh->errstr;
	$sth4->execute() or die "Couldn't execute statement: " . $sth4->errstr;
	#if ($sth4->rows == 0)
	#{
	    #print "No record found\n";
	    #exit;
	#}
	
	print "<tr align=\"CENTER\" valign=\"TOP\"><td>$data2[0]</td><td>$data3[0]</td>";
	my $data4;
	@data4 = $sth4 -> fetchrow_array();
	
	my $mapbuild = "SELECT build_name,ucsc_build_name FROM mapping_genome WHERE id=\"$data4[4]\"";
	my $sth5 = $dbh -> prepare($mapbuild) or die "Couldn't prepare statemnet: " . $dbh -> errstr;
	$sth5->execute() or die "Couldn't execute statement: " . $sth5->errstr;	    
	my @data5;
	if ( $sth5->rows == 0)
	{
	    $data5[0] = "N/A";
	    $data5[1] = "NULL";
	}
	else
	{
	    @data5 = $sth5-> fetchrow_array();
	}

	if ( ($data4[0]==0 & $data4[1]==0))
	{
	    print "<td>N/A</td><td>N/A</td><td>N/A</td><td>N/A</td><td>$data5[0]</td><td><a href=\"http://www.oreganno.org/oregano/recordview.action?recid=$data11[0]\">$data11[0]</a></td><td>N/A</td></tr>";
	}

	else
	{	   
	    if ( $data5[1] eq  "" )
	    {
		print "<td>$data4[0]</td><td>$data4[1]</td><td>$data4[2]</td><td>$data4[3]</td><td>$data5[0]</td><td><a href=\"http://www.oreganno.org/oregano/recordview.action?recid=$data11[0]\">$data11[0]</a></td><td>N/A</td></tr>";
	    }	   

	     else
	    {
		print "<td>$data4[0]</td><td>$data4[1]</td><td>$data4[2]</td><td>$data4[3]</td><td>$data5[0]</td><td><a href=\"http://www.oreganno.org/oregano/recordview.action?recid=$data11[0]\">$data11[0]</a></td><td><a href=\"http://genome.ucsc.edu/cgi-bin/hgTracks?position=$data4[2]:$data4[0]-$data4[1]&db=$data5[1]&oreganno=pack\"><img src=\"http://www.oreganno.org/oregano/htdocs/images/ucsc_logo.png\" width =\"60\" height=\"22\" border=\"\"/></a></td></tr>";
	    }
	}
	 $sth5->finish;
    }   
    $sth2->finish;
    $sth3->finish;
    $sth4->finish;
}
$sth10->finish;
print end_html;
