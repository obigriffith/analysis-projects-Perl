#!/usr/bin/perl
#File: specieslist.pl
use DBI;
use CGI qw/:standard :html3/;

my $host = "web02";
my $user_name = "viewer";
my $password = "d0gf00d";
my $db_name = "oregano";
my $socket_line = "";

#Establish a database connection. DBI returns a database handle object, which we store into $dbh.
my $dbh = DBI->connect("DBI:mysql:host=$host;database=$db_name" . $socket_line, $user_name, $password, {PrintError => 0,
RaiseError => 1}) || die("Cannot connect to ORegAnno MySQL database at $host");


my $species_nameid = "SELECT species_name,id FROM species";
my $sth1 = $dbh-> prepare($species_nameid) or die "Couldn't prepare statement: " . $dbh->errstr;
$sth1->execute() or die "Couldn't execute statement: " . $sth1->errstr;
if ($sth1->rows == 0)
{
    print "No record found\n";
    exit;
}
my @data1;
my %species_nameid;
while (@data1 = $sth1->fetchrow_array())
{
    $species_nameid{$data1[0]} = $data1[1];
}
$sth1->finish;


@keys = keys %species_nameid;
my %finalhash;


foreach $key (@keys)
{
    $value = $species_nameid{$key};
    my $tfname = "SELECT tf_name FROM record WHERE type = \"TRANSCRIPTION FACTOR BINDING SITE\" AND species_id = \"$value\" AND deprecated_by_date IS NULL";
    my $sth3 = $dbh -> prepare($tfname) or die "couldn't prepare statement: ". $dbh -> errstr;
    $sth3 -> execute() or die "Couldn't execute statement: " . $sth3->errstr;
#    if ($sth3->rows == 0)
#    {
#	print "No record found\n";
#	exit;
#    }  
   
    my @date3;
    my %tfnamenum;
    while (@data3 = $sth3 -> fetchrow())
    {
	$data3[0] =~ tr/a-z/A-Z/ ;
	if ( $tfnamenum{$data3[0]} == 0 )
	{
	    $tfnamenum{$data3[0]} = 1;
	}
	else
	{
	    $tfnamenum {$data3[0]}++;
	}
    }
    $sth3-> finish; 
    @tfs = keys %tfnamenum;    
    $numtfs = scalar @tfs;
    $finalhash{$key} = $numtfs;       
}


@numtfs = values %finalhash;
@numtfs = sort {$b <=> $a} @numtfs;
$size = scalar @numtfs;
@keys = keys %species_nameid;
@speciesnamesinorder;

for ($i=0; $i<19; $i++)
{
    for ($k=0; $k <19; $k++)
    {
	if ($finalhash{$keys[$k]} == $numtfs[$i]  & $numtfs[$i] !=0 )
	{
	    $j=0;
	    while ($j < $i)
	    {
		unless ($speciesnamesinorder[$j] eq $keys[$k])
		{
		    $j++;
		}
		else
		{
		    $j =1000;
		}
	    }
	    if ( $j < 500)
	    {
		$speciesnamesinorder[$i] = $keys[$k];
		$k = 1000;	   
	    }
	}
    }
}


print header(),start_html('Species List');
print "<body><p><a href=\"http://www.oreganno.org/oregano/Index.jsp\"><img src=\"http://www.oreganno.org/oregano/htdocs/images/oregano-fulltitle-large.png\" alt=\"ORegAnnoHomePage\" border=\"0\" /></a></p><p align=\"top\"><a href=\"./helppage1.pl\">Help</a></p></body>";

print "<style type=\"text/css\" media=\"screen\"><!-- \@import url(../table.css); --></style><p><b>Species and Number of Transcription Factors</b></p>";

print "<table class='data' border=\"\">";   
print "<tr align=\"CENTER\" valign=\"TOP\"><th>Species</th><th>Number of Transcription Factors</th></tr>";


for ($i=0; $i<17; $i++) 
{   
    print "<tr align=\"CENTER\" valign=\"TOP\"><td><a href=\"./tflist.pl?speciesname=$speciesnamesinorder[$i]\">$speciesnamesinorder[$i]</a></td><td>$numtfs[$i]</td></tr>";
   
}

print end_html;




