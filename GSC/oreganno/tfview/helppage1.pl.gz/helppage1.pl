#!/usr/bin/perl -w

use CGI qw/:standard :html3/;

print header(),start_html('Help Page');

print "<body><p><a href=\"http://www.oreganno.org/oregano/Index.jsp\"><img src=\"http://www.oreganno.org/oregano/htdocs/images/oregano-fulltitle-large.png\" alt=\"ORegAnnoHomePage\" border=\"0\" /></a></p></body>";

print "<p>1. The ORegAnno logo has a link to the ORegAnno home page</p>";

print "<p>2. Each species link takes you to the list of transcription factors for that species as well as binding sites informations for each one</p>";
