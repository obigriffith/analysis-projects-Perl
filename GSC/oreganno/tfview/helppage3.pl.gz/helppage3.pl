#!/usr/bin/perl -w

use CGI qw/:standard :html3/;

print header(),start_html('Help Page');


print "<body><p><a href=\"http://www.oreganno.org/oregano/Index.jsp\"><img src=\"http://www.oreganno.org/oregano/htdocs/images/oregano-fulltitle-large.png\" alt=\"ORegAnnoHomePage\" border=\"0\" /></a></p></body>";

print "<p>1. Link to UCSC will take you to the correct build, chromosome, and coordinates and activates the ORegAnno track, however, only certain species have this track</p>";

print "<p>2. Link to the record's stable id takes you to the record for that particular species, transcription factor and target gene in the ORegAnno web site</p>";

print "<p>3. The UCSC custrom track can also be found from the ORegAnno record page linked from the stable id</p>";
